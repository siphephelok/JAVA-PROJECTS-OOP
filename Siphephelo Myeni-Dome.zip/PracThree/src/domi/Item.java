package domi;

public class Item {
	private String name; //Store the name of the Item
	private String comment; //Store comment about Item
	private double value; //How much cost does the item cost in Rands
	
	/*Constructors default and 
	 * Parameterized
	 */
	
	public Item() { //Unparameterized Constructor
		
	}
	
	public Item(String name) { //Constructor with only name Parameter
		this.name = name;
	}
	
	public Item(String name, String comment) { //Constructor with name & comment Parameters
		this.name = name;
		this.comment = comment;
	}
	
	public Item(String name, String comment, double value) { //Constructor with name, comment & value Parameters
		this.name = name;
		this.comment = comment;
		this.value = value;
	}
	
	//Getters and Setters
	
	public String getName() {
		return this.name;
	}
	
	public String getComment() {
		return this.comment;
	}
	
	public double getValue() {
		return this.value;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setComment(String comment) {
		this.comment = comment;
	}
	
	public void setValue(double value) {
		this.value = value;
	}
	
	/*A Method that returns a
	 *  String representation of the Item
	 */
	
	public String toString() {
		return "Item name is " + this.name + " and its comment is " + this.comment + " and it costs R" + this.value;
	}
	
	/*Method that decreases
	 *  the value of the item by 5%
	 */
	
	public void depreciate(double value) {
		double finalValue = this.value - ( this.value * 0.05);
	}
}
