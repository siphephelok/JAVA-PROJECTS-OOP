package domi;

public class CD extends Item {
	private String artist; //The artist of the song in the CD
	private int playingTime; //The playing time of the tracks in a CD
	
	//Constructor
	
	public CD(String artist, int playingTime,String name, String comment, double value) {
		super(name, comment, value);
		this.artist = artist;
		this.playingTime = playingTime;
	}
	
	//Getters
	
	public String getArtist() {
		return this.artist;
	}
	
	public int getPlayingTime() {
		return this.playingTime;
	}
	
	public String getName() {
		return super.getName();
	}
	public String getComment() {
		return super.getComment();
	}
	public double getValue() {
		return super.getValue();
	}
	
	//Setters
	
	public void setArtist(String artist) {
		this.artist = artist;
	}
	
	public void setPlayingTime(int playingTime) {
		this.playingTime = playingTime;
	}
	
	public void setName(String name) {
		super.setName(name);
	}
	
	public void setComment(String comment) {
		super.setComment(comment);
	}
	
	public void setValue(double value) {
		super.setValue(value);
	}
	
	/*A Method that returns a
	 *  String representation of the Item
	 */
	
	public String toString() {
		return "CD " + super.toString() + " Artist: " + this.artist + " Playing Time " + this.playingTime;
	}
	
	/*Method that decreases
	 *  the value of the item by 10%
	 */
	
	public void depreciate(double value) {
		double finalValue = super.getValue() - ( super.getValue() * 0.10);
	}
}
