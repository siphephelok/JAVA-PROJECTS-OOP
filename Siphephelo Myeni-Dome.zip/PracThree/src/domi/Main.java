package domi;

import java.util.Scanner;

public class Main {
	 private static DataBase db    = new DataBase();
	 private static Scanner input = new Scanner(System.in);


	    /*
	     *  Displays the operation menu for the current active account, and gets
	     *  and returns the current operation
	     */
	    public static int getAChoice() {

	        int choice;

	        while (true) {
	            System.out.println("\nMain menu");
	            System.out.println("   1: Add an item");
	            System.out.println("   2: Remove an item");
	            System.out.println("   3: List all items");
	            System.out.println("   4: Exit");
	            System.out.print("Enter a choice: ");
	            choice = input.nextInt();
	            if (choice < 1 || choice > 4)
	                System.out.println("Illegal choice: please retry");
	            else
	                break;
	        }
	        input.nextLine();
	        return choice;
	    }

	    public static void addItem() {

	        System.out.println("\nAdd an item:");
	        System.out.print("Item name?          ");
	        String name = input.nextLine();
	        System.out.print("Item comment?       ");
	        String comment = input.nextLine();
	        System.out.print("Item cost?          ");
	        double cost = input.nextDouble();
	        System.out.println("Item type? ");
	        int type;
	        while (true) {
	            System.out.println("  1. CD");
	            System.out.println("  2. DVD");
	            System.out.print("Choice? ");
	            type = input.nextInt();
	            if (type < 1 || type > 2)
	                System.out.println("Illegal choice - please retry");
	            else
	                break;
	        }
	        input.nextLine();
	        switch (type) {

	            case 1 : System.out.print("Item artist?        ");
	                String artist = input.nextLine();
	                System.out.print("Item playing time?  ");
	                int playingTime = input.nextInt();
	                input.nextLine();
	                db.add(new CD(artist, playingTime, name, comment, cost));
	                break;

	            case 2 : System.out.print("Item director?      ");
	                String director = input.nextLine();
	                System.out.print("Item running time?  ");
	                int runningTime = input.nextInt();
	                input.nextLine();
	                db.add(new DVD(director,runningTime, name,comment,cost));
	                break;
	        }

	    }

	    public static void removeItem() {
	        System.out.println("\nRemove an item:");
	        System.out.print("Name of the item to remove? ");
	        db.remove(input.nextLine());
	    }
    public static void main(String[] args) {
	// write your code here
    	 boolean exit = false;
         while (! exit) {
             switch (getAChoice()) {
                 case 1  : addItem();
                     break;

                 case 2  : removeItem();
                     break;

                 case 3  : System.out.println("\nItems listing:");
                     db.list();
                     break;

                 case 4  : exit = true;
             }
         }
    }
}
