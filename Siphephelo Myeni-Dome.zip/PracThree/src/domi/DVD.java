package domi;

public class DVD extends Item{
	private String director; //Director of the Movie
	private int runningTime; //How long the movie is
	
	public DVD(String director, int runningTime, String name, String comment, double value) {
		super(name, comment, value);
		this.director = director;
		this.runningTime = runningTime;
	}
	
	//Getters
	
	public String getDirector() {
		return this.director;
	}
	
	public int getRunningTime() {
		return this.runningTime;
	}
	
	public String getName() {
		return super.getName();
	}
	public String getComment() {
		return super.getComment();
	}
	public double getValue() {
		return super.getValue();
	}
	
	//Setters
	
	public void setDirector(String director) {
		this.director = director;
	}
	
	public void setRunningTime(int runningTime) {
		this.runningTime = runningTime;
	}
	
	public void setName(String name) {
		super.setName(name);
	}
	
	public void setComment(String comment) {
		super.setComment(comment);
	}
	
	public void setValue(double value) {
		super.setValue(value);
	}
	
	/*A Method that returns a
	 *  String representation of the Item
	 */
	
	public String toString() {
		return "DVD " + super.toString() + " Director " + this.director + " Running Time " + this.runningTime;
	}
	
	/*Method that decreases
	 *  the value of the item by 15%
	 */
	
	public void depreciate(double value) {
		double finalValue = super.getValue() - ( super.getValue() * 0.15);
	}

}
