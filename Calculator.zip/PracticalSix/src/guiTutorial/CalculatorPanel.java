package guiTutorial;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class CalculatorPanel extends JPanel {
	JTextField xInput, yInput; // input boxes for the numbers
	JTextField answer; // output box for the answer
	double x, y;
	
	public CalculatorPanel() {
		//Create a JLabel and JTextField for the first number ( xInput )
		//The textfield will contain 0 by default 
		
		xInput = new JTextField("0");
		
		//The argument to the JLabel constructor is the string we want the label to contain
		JLabel xLabel = new JLabel(" x= ");
		
		//Create a JPanel to hold this textfield and label
		//Set the layout of the xPanel to BorderLayout . 
		
		JPanel xPanel = new JPanel(new BorderLayout());
		
		//Now add the textfield and the label 
		//The textfield must be in the centre 
		xPanel.add(xInput, BorderLayout.CENTER);
		
		//The label must be to the west of centre of the xPanel
		
		xPanel.add(xLabel, BorderLayout.WEST);
		
		//Create a JLabel and JTextField for the first number ( yInput )
		//The textfield will contain 0 by default 
		yInput = new JTextField("0");
		
		JLabel yLabel = new JLabel(" y= ");
		
		//Create a JPanel to hold this textfield and label
		//Set the layout of the yPanel to BorderLayout.
		
		JPanel yPanel = new JPanel(new BorderLayout());
		
		//Now add the textfield and the label 
		//The textfield must be in the centre 
		
		yPanel.add(yInput, BorderLayout.CENTER);
		
		//The label must be to the west of centre of the yPanel
		
		yPanel.add(yLabel, BorderLayout.WEST);
		
		//Create a JLabel and JTextField for the first number ( aInput )
		//The textfield will contain 0 by default 
		answer = new JTextField("0");
		answer.setEditable(false);	
		JLabel answerLabel = new JLabel(" answer= ");
				
		//Create a JPanel to hold this textfield and label
		//Set the layout of the yPanel to BorderLayout.
				
		JPanel answerPanel = new JPanel(new BorderLayout());
				
		//Now add the textfield and the label 
		//The textfield must be in the centre 
				
		answerPanel.add(answer, BorderLayout.CENTER);
				
		//The label must be to the west of centre of the yPanel
				
		answerPanel.add(answerLabel, BorderLayout.WEST);
		
		//Create buttons
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new GridLayout(1,4));
		
		//Create a Listener Object
		
		ActionListener command = new ButtonListener();
		//Creating the buttons and add each one to the buttonPanel
		JButton additionButton = new JButton("+");
		additionButton.addActionListener(command);
		buttonPanel.add(additionButton);
		JButton subtractButton = new JButton("-");
		subtractButton.addActionListener(command);
		buttonPanel.add(subtractButton);
		JButton multiplyButton = new JButton("*");
		multiplyButton.addActionListener(command);
		buttonPanel.add(multiplyButton);
		JButton divideButton = new JButton("/");
		divideButton.addActionListener(command);
		buttonPanel.add(divideButton);
						
		//Setting layout of the calcPanel 
		
		this.setLayout(new GridLayout(4,1,2,2));
		this.add(xPanel);
		this.add(yPanel);
		this.add(answerPanel);
		this.add(buttonPanel);
		this.setVisible(true);
		
	}
	
	public class ButtonListener implements ActionListener{
		
		@Override
		public void actionPerformed(ActionEvent e) {
			/* Perform the operation based on the action command from the button . 
			 * Note that division by zero 
			 * produces an error message . */
			//Code you wrote in 4.1. above
			//The getActionCommand method of the ActionEvent object
			// returns the name of the object that fired the event . 
			
			try {
				String xStr = xInput.getText();
				x = Double.parseDouble(xStr);
			}catch(NumberFormatException err) {
				// The string xStr is not a 
				// legal number . 
				answer.setText("Illegal data for x ");
			}
			
			try {
				String yStr = yInput.getText();
				y = Double.parseDouble(yStr);
			}catch(NumberFormatException err1) {
				// The string xStr is not a 
				// legal number . 
				answer.setText("Illegal data for y ");
			}
			
			String op = e.getActionCommand(); 
			if (op.equals("+")) // plus button
				answer.setText(x + " + " + y + " = " + (x + y));
			else if(op.equals("-"))
				answer.setText(x + " − " + y + " = " + (x - y)); 
			else if(op.equals("*"))
				answer.setText(x + " * " + y + " = " + (x * y));
			else if(op.equals("/")) {
				if (y == 0)
					answer.setText("Can ’t divide by zero");
				else
					answer.setText(x + " / " + y + " = " + (x / y));
			}//end if
		}//end actionPerformed
		
	}//End class
}

