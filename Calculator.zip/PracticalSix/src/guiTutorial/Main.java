package guiTutorial;
import javax.swing.*;
public class Main {

	public static void main(String[] args) {
		JFrame myFrame = new JFrame();
		myFrame.setSize(400,400);
		myFrame.setLocationRelativeTo(null);
		myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		myFrame.setTitle("Simple Calculator");
		myFrame.add(new CalculatorPanel());
		myFrame.setVisible(true);
	}

}
