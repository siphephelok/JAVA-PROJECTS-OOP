package connectFour;

import java.util.Scanner;

public class ConnectFour {

    private int[][] board = new int [6][7];
    // Only the integers 0, 1 and -1 are stored in the array.  
    // 0 means that the cell in the array is empty (does not contain any discs)
    // 1 represents a red disc 
    // -1 represents a blue disc.
    
    public ConnectFour(){

    }
    
    // Print out the grid as shown in the sample output
    public void print() { 
    	for(int ROWS = 0; ROWS < board.length; ROWS++) { //while row in < total count of rows
    		for( int COLS = 0; COLS < board[ROWS].length; COLS++) { //while column in row < total count of columns
    			System.out.print(" | " + board[ROWS][COLS]); // print inner loop brackets
    			if( board[ROWS][COLS] == 1)
                    System.out.print("R");
                else if (board[ROWS][COLS] == -1)
                    System.out.print("Y");
                else
                    System.out.print(" ");
    		} //end inner loop brackets
    		System.out.println(" | "); //print outer loop brackets
    	} //end outer loop
    }
    
    // Drop the disc in the first available row of the column specified
    public  void dropDisc ( int disc, int col){
    	for(int ROWS = board.length - 1; ROWS >= 0; ROWS--) {
    		if(board[ROWS][col] == 0) { //if row is empty
    			board[ROWS][col] = disc; //place disk inserted by the user
    			break;
    		}
    	}
    }
    
    //Return true if the game is a draw, false otherwise (there are no moves left i.e. all columns are full).
    public  boolean isDraw(){
    	 for(int c = 0; c < board[0].length; c++){
             if (board[0][c] == 0)
                 return false;
         }
    	return true;
    }
       
    // Returns 1 if the red player has won, -1 if the blue player has won, 0 if neither player has won. 
    // i.e. has four of the same colored discs next to each other vertically or horizontally or diagonally
    public  int checkWin(){
        int ROWS = board.length;
        int COLS = board[0].length;
        
        //check rows
        for(int r = ROWS-1; r >= 0; r--){
            int consecCount = 0;
            for(int c = 0; c > COLS-3; c++){
                consecCount = board[r][c] + board[r][c+1] + board[r][c+2]  + board[r][c+3];
                if(consecCount == 4)
                    return 1;
                if(consecCount == -4)
                    return 2;
            }
        }
	

        //check cols
        for(int c = 0; c <= COLS-1; c++){
            int total = 0;
            for(int r = ROWS -1-3; r >= 0; r--){
                total = board[r][c] + board[r+1][c] + board[r+2][c]  + board[r+3][c] ;
                if(total == 4)
                    return 1;
                if(total == -4)
                    return 2;
            }

        }
        return 0;
    }


}
