package connectFour;

import connectFour.ConnectFour;

import java.util.Scanner;

public class ConnectFourApp {

    public static void main(String[] args) {
    	String prompt = "Welcome to the classic Connect Four game!\n\nThis program will start with the red player\nthen move to the yellow player.\n\nYou will chose a numerical value\nbetween 1 and 6 as the column to drop your chip.\n\nOnce you have dropped your chip, the program will scan\nthe columns and rows looking for a win.\nYou can win by having four chips stacked either\nhorizontally, vertically or diagonally.\n\nGood Luck!\n";
    	System.out.println(prompt);
    	System.out.println("========START PROGRAM=========\n");
		Scanner s = new Scanner(System.in);
        ConnectFour connectFour = new ConnectFour();
		connectFour.print();
		
		try {
			while(true){

				System.out.print("Enter a column (0-6) to drop a red disk:");
			    int col = s.nextInt();
				connectFour.dropDisc(1,col);
				connectFour.print();

				if(connectFour.checkWin() == 1){
					System.out.println("Red player wins");
					System.exit(0);
				}
				else if (connectFour.isDraw()) {
					System.out.println("No winner");
					System.exit(0);
				}

				System.out.print("Enter a column (0-6) to drop a yellow disk:");
			    col = s.nextInt();
				connectFour.dropDisc(-1,col);
				connectFour.print();

				if(connectFour.checkWin() == -1){
					System.out.println("Yellow player wins");
					System.exit(0);
				}
				else if (connectFour.isDraw()) {
					System.out.println("No winner");
					System.exit(0);
				}
			}
		} catch (Exception e) {
			System.out.println(e);
			
		}
    }
}
